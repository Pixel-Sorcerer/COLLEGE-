import java.util.Scanner;

public class StackUsingArray {
    int arr[];
    int top;

    StackUsingArray(int max) {
        arr = new int[max];
        top = -1;
    }

    void push(int ele) {
        if (isFull()) {
            System.out.println("Stack Overflow");
        } else {
            top = top + 1;
            arr[top] = ele;
        }
    }

    int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return -1;
        } else {
            int temp = arr[top];
            top = top - 1;
            return temp;
        }
    }

    int top() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return -1;
        } else {
            return arr[top];
        }
    }

    boolean isEmpty() {
        return top == -1;
    }

    boolean isFull() {
        return top == arr.length - 1;
    }

    void print() {
        if (isEmpty()) {
            System.out.println("Stack is empty");
        } else {
            System.out.println("Stack elements:");
            for (int i = 0; i <= top; i++) {
                System.out.print(arr[i] + " ");
            }
            System.out.println();
        }
    }

    int size() {
        return top + 1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the Stack size:");
        int max = sc.nextInt();
        StackUsingArray s = new StackUsingArray(max);
        System.out.println("****MENU*****");
        System.out.println("0: Exit");
        System.out.println("1: Push");
        System.out.println("2: Pop");
        System.out.println("3: Top");
        System.out.println("4: Print Stack");
        System.out.println("5: Stack Size");

        while (true) {
            System.out.print("Enter your choice:");
            int choice = sc.nextInt();
            switch (choice) {
                case 0:
                    System.exit(0);

                case 1:
                    System.out.print("Enter the element:");
                    int ele = sc.nextInt();
                    s.push(ele);
                    break;

                case 2:
                    int m = s.pop();
                    if (m != -1)
                        System.out.println("The popped value is: " + m);
                    break;

                case 3:
                    m = s.top();
                    if (m != -1)
                        System.out.println("The Top value is: " + m);
                    break;

                case 4:
                    s.print();
                    break;

                case 5:
                    System.out.println("Current stack size: " + s.size());
                    break;

                default:
                    System.out.print("Wrong choice");
            }
        }
    }
}
