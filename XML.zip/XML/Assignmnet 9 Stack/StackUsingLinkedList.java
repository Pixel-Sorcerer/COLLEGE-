import java.util.Scanner;

class Node {
    int info;
    Node link;
}

public class StackUsingLinkedList {
    static Node top = null;
    static int size = 0;


    public static boolean isEmpty() {
        return top == null;
    }


    public static void push(int x) {
        Node p = new Node();
        p.info = x;
        p.link = top;
        top = p;
        size++;
//        System.out.println("Pushed element: " + x);
    }


    public static void pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return;
        }
        System.out.println("Popped element: " + top.info);
        top = top.link;
        size--;
    }


    public static void top() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return;
        }
        System.out.println("Top element: " + top.info);
    }


    public static void print() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return;
        }
        System.out.println("Stack elements:");
        Node temp = top;
        while (temp != null) {
            System.out.print(temp.info + " ");
            temp = temp.link;
        }
        System.out.println();
    }


    public static int size() {
        return size;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("**** MENU ****");
        System.out.println("0: Exit");
        System.out.println("1: Push");
        System.out.println("2: Pop");
        System.out.println("3: Top");
        System.out.println("4: Print Stack");
        System.out.println("5: Stack Size");
        while (true) {
            System.out.print("Enter your choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 0:
                    System.out.println("Exit !");
                    System.exit(0);

                case 1:
                    System.out.print("Enter the element: ");
                    int x = sc.nextInt();
                    push(x);
                    break;

                case 2:
                    pop();
                    break;

                case 3:
                    top();
                    break;

                case 4:
                    print();
                    break;

                case 5:
                    System.out.println("Current stack size: " + size());
                    break;

                default:
                    System.out.println("Wrong choice. Please enter a valid option.");
            }
        }
    }
}

