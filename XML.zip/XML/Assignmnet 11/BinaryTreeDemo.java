import java.util.Scanner;

class TreeNode {
    int value;
    TreeNode left, right;

    TreeNode(int value) {
        this.value = value;
    }
}

class BinaryTree {
    TreeNode root;

    void insert(int value) {
        root = insertRec(root, value);
    }

    TreeNode insertRec(TreeNode root, int value) {
        if (root == null) return new TreeNode(value);
        if (value < root.value) root.left = insertRec(root.left, value);
        else if (value > root.value) root.right = insertRec(root.right, value);
        return root;
    }

    void delete(int value) {
        root = deleteRec(root, value);
    }

    TreeNode deleteRec(TreeNode root, int value) {
        if (root == null) return null;
        if (value < root.value) root.left = deleteRec(root.left, value);
        else if (value > root.value) root.right = deleteRec(root.right, value);
        else {
            if (root.left == null) return root.right;
            if (root.right == null) return root.left;
            root.value = minValue(root.right);
            root.right = deleteRec(root.right, root.value);
        }
        return root;
    }

    int minValue(TreeNode root) {
        return root.left == null ? root.value : minValue(root.left);
    }

    void inorder(TreeNode root) {
        if (root != null) {
            inorder(root.left);
            System.out.print(root.value + " ");
            inorder(root.right);
        }
    }

    void display() {
        inorder(root);
        System.out.println();
    }
}

public class BinaryTreeDemo {
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        Scanner sc = new Scanner(System.in);
        System.out.println("\n0:Exit  1:Insert  2:Delete  3:Display");
        while (true) {
            System.out.print("Enter the choice:");
            int ch = sc.nextInt();
            switch (ch) {
                case 0 ->
                        System.exit(0);
                case 1 -> {
                    System.out.print("Enter value to insert: ");
                    int value = sc.nextInt();
                    tree.insert(value);
                }
                case 2 -> {
                    System.out.print("Enter value to delete: ");
                    int value = sc.nextInt();
                    tree.delete(value);
                }
                case 3 -> {
                    System.out.println("Tree in-order traversal:");
                    tree.display();
                }
                default -> System.out.println("Invalid choice");
            }
        }
    }
}

