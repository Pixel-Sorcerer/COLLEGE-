public class Q4 {
    public static void main(String[] args) {
        int arr[] = {2, 4, 6, 8, 10, 12, 14};
        int key = 10;
        System.out.print("Index for key : " + binarySearch(arr, 0, arr.length - 1, key));
    }

    public static int binarySearch(int arr[], int start, int end, int key) {
        if (start > end) {
            return -1; // Key not found
        }

        int mid = (start + end) / 2;

        if (arr[mid] == key) {
            return mid; // Key found
        }

        if (arr[mid] < key) {
            return binarySearch(arr, mid + 1, end, key); // right side search
        } else {
            return binarySearch(arr, start, mid - 1, key); // left side search
        }
    }
}

