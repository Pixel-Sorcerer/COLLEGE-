public class Q1 {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50};
        int reductionCount = 0;
        System.out.println("Original Array: ");
        displayArray(array);
        while (array.length > 1) {
            array = reduceArray(array);
            reductionCount++;
            System.out.println("Array after reduction " + reductionCount + ": ");
            displayArray(array);
        }
        System.out.println("Total number of reductions performed: " + reductionCount);
    }
    public static int[] reduceArray(int[] array) {
        int[] reducedArray = new int[array.length - 1];
        for (int i = 0; i < reducedArray.length; i++) {
            reducedArray[i] = array[i] + array[i + 1];
        }
        return reducedArray;
    }
    public static void displayArray(int[] array) {
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}
