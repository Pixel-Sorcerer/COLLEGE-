import java.util.Scanner;
public class Q3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter size of the array: ");
        int size= sc.nextInt();
        int arr[]=new int[size];
        System.out.print("Enter the elements: ");
        for(int i=0;i<size;i++){
            arr[i]=sc.nextInt();
        }
        if (Sorted(arr)) {
            System.out.println("Yes, reversing a subarray can make the array sorted.");
        } else {
            System.out.println("No, reversing a subarray cannot make the array sorted.");
        }
    }
    public static boolean Sorted(int[] arr) {
        int n = arr.length;
        int start = 0, end = n - 1;
        while (start < n - 1 && arr[start] <= arr[start + 1]) {
            start++;
        }
        if (start == n - 1) {
            return true;
        }
        while (end > 0 && arr[end] >= arr[end - 1]) {
            end--;
        }
        reverse(arr, start, end);
        for (int i = 0; i < n - 1; i++) {
            if (arr[i] > arr[i + 1]) {
                return false;
            }
        }
        return true;
    }
    public static void reverse(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }
}
