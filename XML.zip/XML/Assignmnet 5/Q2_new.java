import java.util.Scanner;

public class Q2_new {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input the first array
        System.out.print("Enter the array1 size: ");
        int n = sc.nextInt();
        System.out.print("Enter the elements of array1:");
        int[] array1 = new int[n];
        for (int i = 0; i < n; i++) {
            array1[i] = sc.nextInt();
        }

        // Input the second array
        System.out.print("Enter the array2 size: ");
        int n1 = sc.nextInt();
        System.out.print("Enter the elements of array2:");
        int[] array2 = new int[n1];
        for (int i = 0; i < n1; i++) {
            array2[i] = sc.nextInt();
        }

        // Merge both arrays into one
        int[] mergedArray = new int[n + n1];
        for (int i = 0; i < n; i++) {
            mergedArray[i] = array1[i];
        }
        for (int i = 0; i < n1; i++) {
            mergedArray[n + i] = array2[i];
        }

        // Sort the merged array using Insertion Sort
        for (int i = 1; i < mergedArray.length; i++) {
            int current = mergedArray[i];
            int j = i - 1;
            while (j >= 0 && mergedArray[j] > current) {
                mergedArray[j + 1] = mergedArray[j];
                j--;
            }
            mergedArray[j + 1] = current;
        }

        // Display the sorted merged array
        System.out.print("Sorted Array:");
        for (int i = 0; i < mergedArray.length; i++) {
            System.out.print(mergedArray[i] + " ");
        }

    }
}
