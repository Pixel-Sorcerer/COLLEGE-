import java.util.Scanner;
// Class to Represent a Node
class Node {
    int info;
    Node next;

}
// Class to Represent the Singly Linked List
public class SinglyLinkedList {
    public static Node head=null;
    // Create a Singly Linked List
    public static void create() {
        Scanner sc=new Scanner (System.in);
        Node p=new Node();
        System.out.print("Input info ");
        p.info=sc.nextInt();
        p.next=null;
        head=p;
        //Adding Remaining Nodes (if any)
        System.out.println("Do you want more nodes(y/n)");
        char ch=sc.next().charAt(0);
        while(ch!='n'){
            Node q=new Node();
            System.out.print("Input info ");
            q.info=sc.nextInt();
            q.next=null;
            p.next=q;
            p=q;
            System.out.println("Do you want more nodes(y/n)");
            ch=sc.next().charAt(0);
        }
    }
    // Display the Content of the Singly Linked List
    public static void traverse() {
        Node temp = head;
        while(temp!=null) {
            System.out.print(temp.info+"--->");
            temp=temp.next;
        }
        System.out.println("null");
    }
    //Count the no. of nodes in the Singly Linked List
    public static int count() {
        int count=0;
        Node temp=head;
        while(temp!=null) {
            count = count + 1;
            temp=temp.next;
        }
        return count;
    }

    // Insert at the Beginning of the Singly Linked List
    public static void insertBeg() {
        Scanner sc=new Scanner (System.in);
        Node p=new Node();
        System.out.print("Input info ");
        p.info=sc.nextInt();
        p.next=head;
        head=p;
    }
    // Insert at the End of the Singly Linked List
    public static void insertEnd() {
        Scanner sc=new Scanner (System.in);
        Node p=new Node();
        System.out.print("Input info ");
        p.info=sc.nextInt();
        if(head==null) {
            head=p;
        }
        else {
            Node temp=head;
            while(temp.next!=null) {
                temp=temp.next;
            }
            temp.next=p;
        }
    }
    // Insert at a Particular Position of the Singly Linked

    public static void insertPos(int pos) {
        Scanner sc=new Scanner (System.in);
        int c=count();
        if(pos>=1&&pos<=c+1) {
            if(pos==1) {
                insertBeg();
            }
            else if(pos==c+1) {
                insertEnd();
            }
            else {
                Node p=new Node();
                System.out.print("Input info ");
                p.info=sc.nextInt();
                Node temp=head;
                int cnt=1;
                while(cnt<pos-1) {
                    cnt++;
                    temp=temp.next;
                }
                p.next=temp.next;
                temp.next=p;
            }
        }
        else {
            System.out.println("Invalid Position");
        }
    }
    // Delete at the Beginning of the Singly Linked List
    public static void deleteBeg() {
        if(head == null) {
            System.out.println("Underflow");
            return;
        }
        head=head.next;
    }
    // Delete at the End of the Singly Linked List
    public static Node deleteEnd(){
        Node temp=head;
        if(head==null) {
            System.out.println("Underflow");
            return null;
        }
        if(head.next==null) {
            head=null;
            return temp;
        }
        else {
            while(temp.next.next!=null) {
                temp=temp.next;
            }
            temp.next=null;
        }
        return temp;
    }
    // Delete at a Particular Position of the Singly Linked
    public static void deletePos() {
        if(head==null) {
            System.out.println("Underflow");
            return;
        }
        Scanner sc=new Scanner (System.in);
        System.out.println("Enter the position");
        int pos=sc.nextInt();
        int c=count();
        if(pos<=c) {
            if(pos==1) {
                deleteBeg();
            }
            else if(pos==c) {
                deleteEnd();
            }
            else {
                Node temp=head;
                int cnt=1;
                while(cnt<pos-1) {
                    cnt++;
                    temp=temp.next;
                }
                temp.next=temp.next.next;
            }
        }
        else {
            System.out.println("Invalid Position");
        }
    }
    // Reverse the Singly Linked List
    public static void reverse() {
        Node pvs = null;
        Node cur = head;
        Node nxt = null;

        while (cur != null) {
            nxt = cur.next;
            cur.next = pvs;
            pvs = cur;
            cur = nxt;
        }
        head = pvs;
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner (System.in);
        while(true) {
            System.out.println("****MENU*****");
            System.out.println("0:Exit\n1:Creation\n2:Traverse(Display)\n3:Insert\n4:Delete\n5:Reverse");
            int ch1=sc.nextInt();
            switch(ch1) {
                case 0:
                    System.exit(0);
                case 1:
                    create();
                    break;
                case 2:
                    traverse();
                    break;

                case 3:
                    System.out.println("****INSERT*****\n1: Beginning\n2: End\n3: Any Position");
                    int ch=sc.nextInt();
                    switch(ch) {
                        case 1:
                            insertBeg();
                            break;
                        case 2:
                            insertEnd();
                            break;
                        case 3:
                            System.out.println("Enter the position");
                            int pos=sc.nextInt();
                            insertPos(pos);
                            break;
                        default:
                            System.out.println("Wrong choice");
                            break;
                    }
                    break;
                case 4:
                    System.out.println("****DELETE*****\n1: Beginning\n2: End\n3: Any Position");
                    System.out.println("Enter the choice");
                    ch=sc.nextInt();
                    switch(ch) {
                        case 1:
                            deleteBeg();
                            break;
                        case 2:
                            Node t = deleteEnd();
                            System.out.println(t.info);
                            break;
                        case 3:
                            deletePos();
                            break;
                        default:
                            System.out.println("Wrong choice");
                            break;
                    }
                    break;
                case 5:
                    reverse();
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }
    }
}
