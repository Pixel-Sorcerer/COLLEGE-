//import java.util.Scanner;
//
//class Node {
//    Node1 prev;
//    int info;
//    Node1 next;
//}
//
//public class DoublyLinkedList {
//    public static Node1 head = null;
//    public static Node1 tail = null;
//
//    public static void create() {
//        Scanner sc = new Scanner(System.in);
//        Node1 p = new Node1();
//        System.out.println("Enter the value");
//        p.info = sc.nextInt();
//        p.next = null;
//        p.prev = null;
//        head = tail = p;
//        System.out.println("Add more? (Y/N)");
//        char ch = sc.next().charAt(0);
//        while (ch == 'y' || ch == 'Y') {
//            Node1 q = new Node1();
//            System.out.println("Enter the value");
//            q.info = sc.nextInt();
//            q.next = null;
//            q.prev = tail;
//            tail.next = q;
//            tail = q;
//            System.out.println("Add more? (Y/N)");
//            ch = sc.next().charAt(0);
//        }
//    }
//
//    public static void traverse() {
//        Node1 temp = head;
//        System.out.println("Forward");
//        System.out.print("null------>");
//        while (temp != null) {
//            System.out.print(temp.info + "------>");
//            temp = temp.next;
//        }
//        System.out.println("null");
////        temp = tail;
////        System.out.println("Backward");
////        System.out.print("null<------");
////        while (temp != null) {
////            System.out.print(temp.info + "<------");
////            temp = temp.prev;
////        }
////        System.out.println("null");
//    }
//
//    public static int count() {
//        Node1 temp = head;
//        int c = 0;
//        while (temp != null) {
//            c++;
//            temp = temp.next;
//        }
//        return c;
//    }
//
//    public static void insertBeg() {
//        Scanner sc = new Scanner(System.in);
//        Node1 p = new Node1();
//        System.out.println("Enter the value");
//        p.info = sc.nextInt();
//        if (head == null) {
//            p.prev = p.next = null;
//            head = tail = p;
//        } else {
//            p.next = head;
//            p.prev = null;
//            head.prev = p;
//            head = p;
//        }
//    }
//
//    public static void insertEnd() {
//        Scanner sc = new Scanner(System.in);
//        Node1 p = new Node1();
//        System.out.println("Enter the value");
//        p.info = sc.nextInt();
//        if (head == null) {
//            p.prev = p.next = null;
//            head = tail = p;
//        } else {
//            p.prev = tail;
//            p.next = null;
//            tail.next = p;
//            tail = p;
//        }
//    }
//
//    public static void insertPos(int pos) {
//        Scanner sc = new Scanner(System.in);
//        int count = count();
//        if (pos >= 1 && pos <= count + 1) {
//            if (pos == 1)
//                insertBeg();
//            else if (pos == count + 1)
//                insertEnd();
//            else {
//                int cnt = 1;
//                Node1 temp = head;
//                while (cnt < pos) {
//                    cnt = cnt + 1;
//                    temp = temp.next;
//                }
//                Node1 p = new Node1();
//                System.out.println("Enter the value");
//                p.info = sc.nextInt();
//                p.prev = temp.prev;
//                p.next = temp;
//                temp.prev.next = p;
//                temp.prev = p;
//            }
//        } else {
//            System.out.println("Invalid position");
//        }
//    }
//
//    public static void delBeg() {
//        if (head == null) {
//            System.out.println("Underflow");
//        } else if (head.next == null)
//            head = tail = null;
//        else {
//            head = head.next;
//            head.prev = null;
//        }
//    }
//
//    public static void delEnd() {
//        if (head == null) {
//            System.out.println("Underflow");
//        } else if (head.next == null)
//            head = tail = null;
//        else {
//            tail = tail.prev;
//            tail.next = null;
//        }
//    }
//
//    public static void delPos() {
//        Scanner sc = new Scanner(System.in);
//        if (head == null) {
//            System.out.println("Underflow");
//            return;
//        }
//        System.out.println("Enter the position");
//        int pos = sc.nextInt();
//        int count = count();
//        if (pos >= 1 && pos <= count) {
//            if (pos == 1)
//                delBeg();
//            else if (pos == count)
//                delEnd();
//            else {
//                int cnt = 1;
//                Node1 temp = head;
//                while (cnt < pos) {
//                    cnt = cnt + 1;
//                    temp = temp.next;
//                }
//                temp.prev.next = temp.next;
//                temp.next.prev = temp.prev;
//                temp.next = null;
//            }
//        } else
//            System.out.println("Invalid position");
//    }
//
//    public static void reverse() {
//        if (head == null) {
//            System.out.println("The list is empty. Nothing to reverse.");
//            return;
//        }
//        Node1 curr = head;
//        Node1 temp = null;
//
//        while (curr != null) {
//            temp = curr.prev;
//            curr.prev = curr.next;
//            curr.next = temp;
//            curr = curr.prev;
//        }
//
//
//        if (temp != null) {
//            head = temp.prev;
//        }
//        System.out.println("The list has been reversed.");
//    }
//
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        while (true) {
//            System.out.println("****MENU*****");
//            System.out.println("0: Exit");
//            System.out.println("1: Creation");
//            System.out.println("2: Traverse(Display)");
//            System.out.println("3: Count");
//            System.out.println("4: Insert");
//            System.out.println("5: Delete");
//            System.out.println("6: Reverse");
//            System.out.println("*************");
//            System.out.println("Enter the choice");
//            int choice = sc.nextInt();
//            switch (choice) {
//                case 0:
//                    System.exit(0);
//                case 1:
//                    create();
//                    break;
//                case 2:
//                    traverse();
//                    break;
//                case 3:
//                    System.out.println("No. of Nodes = " + count());
//                    break;
//                case 4:
//                    System.out.println("****INSERT*****");
//                    System.out.println("1: Beginning");
//                    System.out.println("2: End");
//                    System.out.println("3: Specific Position");
//                    System.out.println("Enter the choice");
//                    int ch = sc.nextInt();
//                    switch (ch) {
//                        case 1:
//                            insertBeg();
//                            break;
//                        case 2:
//                            insertEnd();
//                            break;
//                        case 3:
//                            System.out.println("Enter the position");
//                            int pos = sc.nextInt();
//                            insertPos(pos);
//                            break;
//                        default:
//                            System.out.println("Wrong choice");
//                            break;
//                    }
//                    break;
//                case 5:
//                    System.out.println("****DELETE*****");
//                    System.out.println("1: Beginning");
//                    System.out.println("2: End");
//                    System.out.println("3: Specific Position");
//                    System.out.println("Enter the choice");
//                    ch = sc.nextInt();
//                    switch (ch) {
//                        case 1:
//                            delBeg();
//                            break;
//                        case 2:
//                            delEnd();
//                            break;
//                        case 3:
//                            delPos();
//                            break;
//                        default:
//                            System.out.println("Wrong choice");
//                            break;
//                    }
//                    break;
//                case 6:
//                    reverse();
//                    break;
//                default:
//                    System.out.println("Wrong choice");
//            }
//        }
//    }
//}
