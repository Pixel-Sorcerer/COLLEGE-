import java.util.Scanner;
public class A2Q5 {
    public static void main(String[] args){
        int a=0,b=1,c;
        System.out.print("Enter the number up to which you want to find the fibonacci series:- ");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int i=1; i<=n; i++){
            System.out.print(a+" ");
            c=a+b;
            a=b;
            b=c;
        }
    }
}
