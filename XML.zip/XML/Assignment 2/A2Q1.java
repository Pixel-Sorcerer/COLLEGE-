import java.util.Scanner;
public class A2Q1 {
    static int maxSumArr(int nums[]) {
        int sum=0;
        int maxSum=nums[0];
        for (int i=0;i< nums.length;i++){
            sum=sum+nums[i];
            if (sum>maxSum){
                maxSum=sum;
            }
            if(sum<0){
                sum=0;
            }
        }
        return maxSum;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();
        System.out.println("Enter the elements of the array:");
        int nums[]=new int[n];
        for (int i = 0; i < n; i++) {
            nums[i] = sc.nextInt();
        }
        System.out.println("Largest sum ="+maxSumArr(nums));
    }
}
