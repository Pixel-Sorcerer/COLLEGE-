import java.util.Scanner;
public class A2Q4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number for which you want to find the factorial: ");
        int n=sc.nextInt();
        int fact=1;
        for (int i=1;i<=n;i++){
            fact=fact*i;
        }
        System.out.println("The factorial of "+n+" is "+fact);
    }
}
