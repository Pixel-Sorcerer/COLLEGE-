import java.util.Scanner;
public class A2Q2 {
       static int missingNumber(int arr[], int size) {
            int num = 1;
            for (int i = 0; i < size; i++) {
                if (arr[i] == num) {
                    num++;
                }
            }
            return num;
        }
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter the number of elements: ");
            int n = sc.nextInt();
            System.out.println("Enter the elements of the array:");
            int arr[]=new int[n];
            for (int i = 0; i < n; i++) {
                arr[i] = sc.nextInt();
            }
            int size = arr.length;
            for(int i=0;i<size;i++) {
                for (int j=i+1;j<size;j++) {
                    if(arr[i]>arr[j]) {
                        int temp=arr[i];
                        arr[i]=arr[j];
                        arr[j]=temp;
                    }
                }
            }
            System.out.println("The smallest missing positive number is: " + missingNumber(arr, size));
        }
}

