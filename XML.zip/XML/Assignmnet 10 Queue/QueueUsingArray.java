import java.util.Scanner;

public class QueueUsingArray {
    int arr[];
    int front, rear;

    QueueUsingArray(int max) {
        arr = new int[max];
        front = rear = -1;
    }

    void add(int e) {
        if (is_full()) {
            System.out.println("Queue Overflow");
            return;
        } else if (front == -1 && rear == -1)
            front = rear = 0;
        else
            rear = rear + 1;
        arr[rear] = e;
    }

    void remove() {
        if (is_empty()) {
            System.out.println("Queue Underflow");
        } else {
            System.out.println("Deleted element: " + arr[front]);
            if (front == rear)
                front = rear = -1;
            else
                front = front + 1;
        }
    }

    void print() {
        if (is_empty()) {
            System.out.println("Queue Underflow");
        } else {
            System.out.print("Stack elements:");
            for (int i = front; i <= rear; i++)
                System.out.print(arr[i] + " ");
            System.out.println();
        }
    }

    boolean is_empty() {
        return front == -1 && rear == -1;
    }

    boolean is_full() {
        return rear == arr.length - 1;
    }

    int size() {
        if (is_empty()) {
            return 0;
        } else {
            return rear - front + 1;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of Queue:");
        int s = sc.nextInt();
        QueueUsingArray ob = new QueueUsingArray(s);
        System.out.println("****MENU*****");
        System.out.println("0: Exit");
        System.out.println("1: Add");
        System.out.println("2: Remove");
        System.out.println("3: Print");
        System.out.println("4: Size");

        while (true) {

            System.out.print("Enter your choice:");
            int ch = sc.nextInt();

            switch (ch) {
                case 0:
                    System.exit(0);
                case 1:
                    System.out.print("Enter the element:");
                    int e = sc.nextInt();
                    ob.add(e);
                    break;
                case 2:
                    ob.remove();
                    break;
                case 3:
                    ob.print();
                    break;
                case 4:
                    System.out.println("Current size of the queue: " + ob.size());
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }
    }
}
