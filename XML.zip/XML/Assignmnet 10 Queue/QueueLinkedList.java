import java.util.Scanner;
class Node {
    int info;
    Node link;
}
public class QueueLinkedList {
    static Node front = null;
    static Node rear = null;
    public static void add(int e) {
        Node p = new Node();
        p.info = e;
        p.link = null;

        if (rear == null)
            front = rear = p;
        else {
            rear.link = p;
            rear = p;
        }
    }
    public static void remove() {
        if (front == null) {
            System.out.println("Queue Underflow");
            return;
        }
        System.out.println("Deleted value is: " + front.info);
        front = front.link;
        if (front == null)
            rear = null;
    }
    public static void print() {
        if (front == null) {
            System.out.println("Queue Underflow");
            return;
        }
        Node temp = front;
        while (temp != null) {
            System.out.print(temp.info + " ");
            temp = temp.link;
        }
        System.out.println();

    }
    public static void size() {
        int count = 0;
        Node temp = front;
        while (temp != null) {
            count++;
            temp = temp.link;
        }
        System.out.println("Queue size is: " + count);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("****MENU*****");
            System.out.println("0: Exit");
            System.out.println("1: Add");
            System.out.println("2: Remove");
            System.out.println("3: Print");
            System.out.println("4: Size");
            System.out.print("Enter the choice:");
            int ch = sc.nextInt();
            switch (ch) {
                case 0:
                    System.exit(0);
                case 1:
                    System.out.println("Enter the element:");
                    int e = sc.nextInt();
                    add(e);
                    break;
                case 2:
                    remove();
                    break;
                case 3:
                    print();
                    break;
                case 4:
                    size();
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }
    }
}
