import java.util.Scanner;
public class A3Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();
        System.out.println("Enter the elements of the array:");
        int num[]=new int[n];
        for (int i = 0; i < n; i++) {
            num[i] = sc.nextInt();
        }
        int l=num.length-1;
        int maximum=num[0];
        int minimum=num[0];
        System.out.println("Maximum Number: " + max(num, l, maximum));
        System.out.println("Minimum Number: " + min(num, l, minimum));

    }

    static int max(int[] num, int l, int maximum) {
        if (l == 0)
            return maximum;
        if (l > 0) {
            if (num[l] > maximum) {
                maximum = num[l];
            }
        }
        return max(num, l - 1, maximum);
    }
    static int min(int[] num, int l, int minimum) {
        if (l == 0)
            return minimum;
        if (l > 0) {
            if (num[l] < minimum) {
                minimum = num[l];
            }
        }
        return min(num, l - 1, minimum);
    }
}