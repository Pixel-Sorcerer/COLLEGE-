import java.util.Scanner;
public class A3Q8 {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        System.out.print("Enter a Decimal number: ");
        int n = ob.nextInt();
        if(n==0)
            System.out.println("The Hexadecimal equivalent number is: 0");
        else
            System.out.println("The Hexadecimal equivalent number is: "+hex(n));
    }
    static String hex(int n){
        if (n==0)
            return "";
        char a[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        int r = n%16;
        return hex(n/16)+a[r];
    }
}