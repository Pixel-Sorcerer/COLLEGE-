import java.util.Scanner;

public class A3Q1 {
    public static int sum(int n) {
        if (n == 1) {
            return 1;
        } else {
            return n + sum(n - 1);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = sc.nextInt();
        int sum = sum(n);
        System.out.println("The sum of the first " + n + " natural numbers is: " + sum);
    }


}