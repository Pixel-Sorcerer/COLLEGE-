import java.util.Scanner;
public class A3Q6 {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        System.out.print("Enter the size of array: ");
        int n = ob.nextInt();
        int[] arr = new int[n];
        System.out.print("Enter the elements of array: ");
        for (int i = 0; i < n; i++) {
            arr[i] = ob.nextInt();
        }
        System.out.println("The smallest missing positive number is: " + missing(arr, 1));
    }
    public static int missing(int[] arr, int n) {
        return find(arr, n, 0);
    }
    static int find(int[] arr, int n, int index) {
        if (index == arr.length)
            return n;
        if (arr[index] == n)
            return missing(arr, n + 1);
        return find(arr, n, index + 1);
    }
}