import java.util.Arrays;
import java.util.Scanner;

public class A1Q3 {

    public void rotate(int[] nums, int k) {
        k = k % nums.length;
        reverse(nums, 0, nums.length - 1);
        reverse(nums, 0, k - 1);
        reverse(nums, k, nums.length - 1);
    }

    public void reverse(int[] nums, int start, int end) {
        while (start < end) {
            int temp = nums[start];
            nums[start] = nums[end];
            nums[end] = temp;
            start++;
            end--;
        }
    }

    public static void main(String[] args) {
        A1Q3 solution = new A1Q3();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements:");

        int n = sc.nextInt();
        int[] nums = new int[n];

        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            nums[i] = sc.nextInt();
        }
        System.out.println("Enter the K value:");
        int k = sc.nextInt();

        System.out.println("Original Array: " + Arrays.toString(nums));

        solution.rotate(nums, k);

        System.out.println("Array after rotating by " + k + " steps: " + Arrays.toString(nums));
    }
}