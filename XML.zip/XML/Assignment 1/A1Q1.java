import java.util.Scanner;
public class A1Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("how many no you want to enter ");
        int a = sc.nextInt();
        int sum =0;
        System.out.println("Enter the no");
        for(int i=0 ; i<a;i++) {
            int x = sc.nextInt();
            sum = sum+x;
        }
        System.out.println("Sum is:-"+sum);

    }

}