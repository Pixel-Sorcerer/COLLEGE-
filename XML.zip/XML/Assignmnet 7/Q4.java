import java.util.Arrays;

public class Q4 {
    public static void main(String[] args) {
        int[] arr = {3, 8, 15, 17};
        int[][] result = find(arr);
        System.out.println("Pair with minimum difference: (" + result[0][0] + ", " + result[0][1] + ")");
        System.out.println("Pair with maximum difference: (" + result[1][0] + ", " + result[1][1] + ")");
    }

    public static int[][] find(int[] arr) {
        Arrays.sort(arr);
        int minDiff = Integer.MAX_VALUE;
        int[] minPair = new int[2];
        int[] maxPair = new int[2];

        for (int i = 0; i < arr.length - 1; i++) {
            int diff = arr[i + 1] - arr[i];
            if (diff < minDiff) {
                minDiff = diff;
                minPair[0] = arr[i];
                minPair[1] = arr[i + 1];
            }
        }

        maxPair[0] = arr[0];
        maxPair[1] = arr[arr.length - 1];
        return new int[][]{minPair, maxPair};
    }
}
