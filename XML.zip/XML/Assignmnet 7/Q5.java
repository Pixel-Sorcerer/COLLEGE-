public class Q5 {
    public static void main(String[] args) {
        int[] array = {1, 5, 2, 3, 5, 3, 5};

        int maxElement = array[0];
        int maxCount = 0;

        for (int i = 0; i < array.length; i++) {
            int count = 0;
            for (int j = 0; j < array.length; j++) {
                if (array[i] == array[j]) {
                    count++;
                }
            }
            if (count > maxCount) {
                maxCount = count;
                maxElement = array[i];
            }
        }

        System.out.println("Element with maximum occurrences: " + maxElement);
        System.out.println("Occurrences: " + maxCount);
    }
}

