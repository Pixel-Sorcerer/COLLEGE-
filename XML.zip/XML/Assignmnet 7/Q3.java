public class Q3 {
    public static void main(String[] args) {
        int arr[] = {61,63,64,65};
        int n = arr.length + 1;
        int totalSum = n * (arr[0] + arr[arr.length-1]) / 2;
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        int missingNumber = totalSum - sum;
        System.out.println("Missing number is: " + missingNumber);
    }
}

